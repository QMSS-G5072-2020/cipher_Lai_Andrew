# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cipher_ael2193']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cipher-ael2193',
    'version': '0.1.0',
    'description': 'Python package that uses cipher function to transform words',
    'long_description': None,
    'author': 'Andrew',
    'author_email': 'ael2193@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
